// Graphics Library

let cnv = document.getElementById("my-canvas");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

// Draw a Line
stroke("blue");
lineWidth(3);
line(100, 200, 300, 100);

stroke("red");
line(500, 50, 300, 450);
line(0, 0, 100, 100);

// Draw a Rectangle
fill("orange");
rect(100, 100, 200, 50, "fill");
rect(400, 500, 70, 100, "stroke");

// Draw a Circle
circle(400, 300, 50, "stroke");
fill("green");
circle(700, 300, 25, "fill");

// Draw a Triangle
stroke("purple");
triangle(0, 400, 300, 400, 250, 450, "fill");
triangle(0, 300, 400, 300, 350, 250, "stroke");

// Draw some Text
font("44px Arial")
text("Hello", 500, 300, "fill");
text("Goodbye", 250, 550, "stroke");

// Draw an ellipse
fill("blue");
ellipse(700, 100, 10, 80, 0, "fill");
lineWidth(5);
ellipse(700, 500, 150, 25, 0, "stroke");

// Draw an Image
let chessImgEl = document.createElement("img");
chessImgEl.src = "img/chess.jpg";

window.addEventListener("load", draw);

function draw() {
    image(chessImgEl, 0, 0, 300, 200);
}
